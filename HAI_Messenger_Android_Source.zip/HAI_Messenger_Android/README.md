# HAI Messenger Android - UI Starter
Target: Android / Kotlin / Jetpack Compose
Package: ir.haicraft.messenger
Version: 1.0.0

## Open
1. Extract this ZIP.
2. Open the `HAI_Messenger_Android` folder in Android Studio.
3. Allow Gradle sync.
4. Run on an Android device or emulator.

## Current scope
This is an interactive UI starter/demo. It includes Chats, Groups, Channels, Status, Profile and an Admin preview, plus a demo conversation with local in-memory messages.

## Not yet connected
There is no real account system, remote database, push notifications, server-side admin authorization, cross-device sync, or actual file upload. The attach button is visual only. Do not use this demo to store private messages. A production messenger needs a secure backend, authentication, access rules, file storage, abuse reporting and privacy review.
