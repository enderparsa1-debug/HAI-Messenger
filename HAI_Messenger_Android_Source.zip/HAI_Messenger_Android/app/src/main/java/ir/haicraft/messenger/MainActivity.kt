package ir.haicraft.messenger

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Purple = Color(0xFF7C3AED)
private val Deep = Color(0xFF171321)
private val Panel = Color(0xFF241D33)
private val Muted = Color(0xFFB9AEC9)
private val White = Color(0xFFF8F6FC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HaiApp() }
    }
}

data class ChatItem(val name: String, val message: String, val time: String, val unread: Int = 0, val group: Boolean = false)

@Composable
fun HaiApp() {
    var tab by remember { mutableStateOf("Chats") }
    var selected by remember { mutableStateOf<ChatItem?>(null) }
    var draft by remember { mutableStateOf("") }
    var sent by remember { mutableStateOf(listOf<String>()) }
    val chats = remember {
        listOf(
            ChatItem("Armin", "Are we playing tonight?", "19:42", 2),
            ChatItem("HAI CRAFT Team", "Server update is ready", "18:10", 5, true),
            ChatItem("Design Group", "New purple theme looks good", "Yesterday", 0, true),
            ChatItem("Nexa", "See you later", "Yesterday")
        )
    }
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Purple, background = Deep, surface = Panel,
        onPrimary = White, onBackground = White, onSurface = White
    )) {
        Surface(Modifier.fillMaxSize(), color = Deep) {
            if (selected != null) {
                ChatScreen(selected!!, sent, draft, { draft = it }, {
                    if (draft.isNotBlank()) { sent = sent + draft; draft = "" }
                }, { selected = null })
            } else {
                Column(Modifier.fillMaxSize()) {
                    Header(tab)
                    when (tab) {
                        "Chats" -> ChatsScreen(chats) { selected = it }
                        "Groups" -> SimpleList("Your groups", listOf("HAI CRAFT Team", "Design Group", "Friends"), "Create group")
                        "Channels" -> SimpleList("Discover channels", listOf("HAI CRAFT News", "Minecraft Updates", "Community"), "Create channel")
                        "Status" -> StatusScreen()
                        "Profile" -> ProfileScreen()
                        "Admin" -> AdminScreen()
                    }
                    NavigationBar(containerColor = Panel, contentColor = White) {
                        val items = listOf("Chats" to Icons.Default.Chat, "Groups" to Icons.Default.Groups,
                            "Channels" to Icons.Default.Campaign, "Status" to Icons.Default.Circle,
                            "Profile" to Icons.Default.Person, "Admin" to Icons.Default.Settings)
                        items.forEach { (name, icon) ->
                            NavigationBarItem(selected = tab == name, onClick = { tab = name },
                                icon = { Icon(icon, contentDescription = name) },
                                label = { Text(name, fontSize = 10.sp) },
                                colors = NavigationBarItemDefaults.colors(selectedIconColor = White,
                                    indicatorColor = Purple, unselectedIconColor = Muted,
                                    selectedTextColor = White, unselectedTextColor = Muted))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun Header(tab: String) {
    Row(Modifier.fillMaxWidth().background(Panel).padding(horizontal = 18.dp, vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(42.dp).background(Purple, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
            Text("H", color = White, fontWeight = FontWeight.Black, fontSize = 25.sp)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("HAI MESSENGER", color = White, fontWeight = FontWeight.Black, fontSize = 17.sp)
            Text(tab, color = Muted, fontSize = 12.sp)
        }
        Icon(Icons.Default.Search, contentDescription = "Search", tint = White)
        Spacer(Modifier.width(14.dp))
        Icon(Icons.Default.MoreVert, contentDescription = "More", tint = White)
    }
}

@Composable
fun ChatsScreen(chats: List<ChatItem>, onOpen: (ChatItem) -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Messages", color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("Your conversations, in one place.", color = Muted, modifier = Modifier.padding(top = 4.dp, bottom = 16.dp))
        chats.forEach { chat ->
            Row(Modifier.fillMaxWidth().clickable { onOpen(chat) }.padding(vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Avatar(chat.name, chat.group)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(chat.name, color = White, fontWeight = FontWeight.SemiBold)
                    Text(chat.message, color = Muted, fontSize = 13.sp, maxLines = 1)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(chat.time, color = Muted, fontSize = 11.sp)
                    if (chat.unread > 0) Box(Modifier.padding(top = 6.dp).background(Purple, CircleShape).padding(horizontal = 7.dp, vertical = 3.dp)) {
                        Text(chat.unread.toString(), color = White, fontSize = 10.sp)
                    }
                }
            }
            HorizontalDivider(color = Color(0xFF3B314B))
        }
    }
}

@Composable
fun Avatar(label: String, group: Boolean = false) {
    Box(Modifier.size(48.dp).background(if (group) Color(0xFF45315F) else Purple.copy(alpha = .75f), CircleShape),
        contentAlignment = Alignment.Center) {
        Text(if (group) "✦" else label.take(1).uppercase(), color = White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
    }
}

@Composable
fun ChatScreen(chat: ChatItem, sent: List<String>, draft: String, onDraft: (String) -> Unit, onSend: () -> Unit, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().background(Panel).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = White, modifier = Modifier.clickable { onBack() })
            Spacer(Modifier.width(12.dp)); Avatar(chat.name, chat.group); Spacer(Modifier.width(10.dp))
            Column { Text(chat.name, color = White, fontWeight = FontWeight.Bold); Text("Demo conversation", color = Muted, fontSize = 11.sp) }
        }
        Column(Modifier.weight(1f).fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.Bottom) {
            MessageBubble("Welcome to HAI Messenger. This is a local UI preview.", false)
            sent.forEach { MessageBubble(it, true) }
        }
        Row(Modifier.fillMaxWidth().background(Panel).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.AttachFile, contentDescription = "Attach file (demo)", tint = Muted)
            Spacer(Modifier.width(8.dp))
            OutlinedTextField(value = draft, onValueChange = onDraft, modifier = Modifier.weight(1f),
                placeholder = { Text("Write a message…", color = Muted) }, singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Purple, unfocusedBorderColor = Color(0xFF51465F), focusedTextColor = White, unfocusedTextColor = White))
            Spacer(Modifier.width(8.dp))
            IconButton(onClick = onSend) { Icon(Icons.Default.Send, contentDescription = "Send", tint = Purple) }
        }
    }
}

@Composable
fun MessageBubble(text: String, mine: Boolean) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
        Surface(color = if (mine) Purple else Panel, shape = RoundedCornerShape(16.dp), modifier = Modifier.padding(vertical = 4.dp)) {
            Text(text, color = White, modifier = Modifier.padding(12.dp))
        }
    }
}

@Composable
fun SimpleList(title: String, entries: List<String>, action: String) {
    var show by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(title, color = White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        entries.forEach { Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Avatar(it, true); Spacer(Modifier.width(12.dp)); Text(it, color = White, modifier = Modifier.weight(1f)); Icon(Icons.Default.ChevronRight, null, tint = Muted)
        } }
        Spacer(Modifier.height(12.dp))
        Button(onClick = { show = true }, colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Text(action) }
    }
    if (show) AlertDialog(onDismissRequest = { show = false }, title = { Text(action) },
        text = { OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Name") }) },
        confirmButton = { TextButton(onClick = { show = false; name = "" }) { Text("Create (demo)") } },
        dismissButton = { TextButton(onClick = { show = false }) { Text("Cancel") } })
}

@Composable
fun StatusScreen() {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Status", color = White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Share a short update with your contacts.", color = Muted, modifier = Modifier.padding(top = 4.dp, bottom = 18.dp))
        var status by remember { mutableStateOf("") }
        OutlinedTextField(status, { status = it }, modifier = Modifier.fillMaxWidth(), label = { Text("What's happening?") })
        Button(onClick = { status = "" }, modifier = Modifier.padding(top = 10.dp), colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Text("Post status (demo)") }
        listOf("Armin · Online now", "Nexa · 2 hours ago", "HAI CRAFT · Yesterday").forEach {
            Text(it, color = White, modifier = Modifier.padding(top = 20.dp))
        }
    }
}

@Composable
fun ProfileScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(24.dp)); Avatar("Vexor"); Spacer(Modifier.height(12.dp))
        Text("Your profile", color = White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Text("@your_username", color = Muted)
        Spacer(Modifier.height(24.dp))
        listOf("Edit profile", "Privacy", "Notifications", "Files and storage", "About HAI Messenger").forEach {
            Row(Modifier.fillMaxWidth().padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(it, color = White, modifier = Modifier.weight(1f)); Icon(Icons.Default.ChevronRight, null, tint = Muted)
            }
            HorizontalDivider(color = Color(0xFF3B314B))
        }
    }
}

@Composable
fun AdminScreen() {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Admin Panel", color = White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Local preview only · admin access is not secured yet", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp))
        listOf("Users" to "0 reports pending", "Groups" to "Manage communities", "Channels" to "Manage broadcasts", "Reports" to "Review user reports", "App settings" to "Configuration").forEach { (a,b) ->
            Surface(color = Panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AdminPanelSettings, null, tint = Purple); Spacer(Modifier.width(12.dp))
                    Column { Text(a, color = White, fontWeight = FontWeight.SemiBold); Text(b, color = Muted, fontSize = 12.sp) }
                }
            }
        }
    }
}
